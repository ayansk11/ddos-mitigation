# XDP DDoS Filter

This component implements a high-performance DDoS filter inside the Linux
kernel using the XDP (eXpress Data Path) framework.

## Steps Performed

### 1. Compiling the XDP Program
